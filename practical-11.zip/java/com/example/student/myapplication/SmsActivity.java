package com.example.student.myapplication;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SmsActivity extends AppCompatActivity {
    EditText no,msg;
    SmsManager sm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        no=findViewById(R.id.etnumber);
        msg=findViewById(R.id.etmsg);
        if(Build.VERSION.SDK_INT>=23)
        {
            if(ActivityCompat.checkSelfPermission(this,Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)
            {
                requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS},10);
            }
        }

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==5) {

        }
    }
    public void sendmsg(View view) {
        String phno=no.getText().toString();
        String text=msg.getText().toString();
        if(Build.VERSION.SDK_INT>=23) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 5);
            } else {
                Intent i = new Intent(this, SmsActivity.class);
                PendingIntent po = PendingIntent.getActivities(this, 5, new Intent[]{i}, PendingIntent.FLAG_CANCEL_CURRENT);
                sm = SmsManager.getDefault();
                sm.sendTextMessage(phno, null, text, po, null);
                Toast.makeText(this, "Sms Send", Toast.LENGTH_LONG).show();
            }
         } else{
            Intent i = new Intent(this, SmsActivity.class);
            PendingIntent po = PendingIntent.getActivities(this, 5, new Intent[]{i}, PendingIntent.FLAG_CANCEL_CURRENT);
            sm = SmsManager.getDefault();
            sm.sendTextMessage(phno, null, text, po, null);
            Toast.makeText(this, "Sms Send", Toast.LENGTH_LONG).show();
        }

    }
}
