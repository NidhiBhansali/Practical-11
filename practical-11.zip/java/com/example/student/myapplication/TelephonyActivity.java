package com.example.student.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TelephonyActivity extends AppCompatActivity {
    TextView detail;
    TelephonyManager tm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telephony);
        detail=findViewById(R.id.txtdetail);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==5) {

        }
    }

    public void Display(View view) {
        tm=(TelephonyManager)getSystemService(getApplicationContext().TELEPHONY_SERVICE);
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)
        {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},5);
        }
        String IMEINumber=tm.getDeviceId();
        String Subscriberid=tm.getSubscriberId();
        String SimSerialNo=tm.getSimSerialNumber();
        String phoneno=tm.getLine1Number();
        String SoftwareVersion=tm.getDeviceSoftwareVersion();
        String voicemailNumber=tm.getVoiceMailNumber();
        String simoperatorname=tm.getSimOperator();
       int phonestatus=tm.getCallState();

        String slotemi="";
        if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
          slotemi=tm.getImei();
        }
       //GetPhonetYpe
        String strphonetype="";
        String status=null;
        int phonetype=tm.getPhoneType();
        String tag="Status is";
        switch (phonestatus)
        {
            case TelephonyManager.CALL_STATE_IDLE:
                status="Phone is Idle";
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                status="Phone is in Use";
                break;
            case TelephonyManager.CALL_STATE_RINGING:
                status="Phone is Ringing";
                break;

        }
        switch (phonetype)
        {
            case TelephonyManager.PHONE_TYPE_CDMA:
                strphonetype="CDMA";
                break;
            case TelephonyManager.PHONE_TYPE_GSM:
                strphonetype="GSM";
                break;
            case TelephonyManager.PHONE_TYPE_NONE:
                strphonetype="none";
                break;

        }
        String datainfo="";
      //Check Data Connected or not
        switch (tm.getDataState())
        {
            case TelephonyManager.DATA_CONNECTED:
                datainfo="Connected";
                break;
            case TelephonyManager.DATA_DISCONNECTED:
               datainfo="Disconnected";
                break;
            case TelephonyManager.DATA_ACTIVITY_IN:
                datainfo="Data Incoming Only";
                break;
            case TelephonyManager.DATA_ACTIVITY_INOUT:
                datainfo="Data Incoming and Outgoing Both";
                break;



        }
        //Getting information if phone is Roming
        boolean isRoming=tm.isNetworkRoaming();
        String info="Phone Details:\n";
        info+="\nIMEI NUmber=" + IMEINumber;
        info+="\nSubscriberid="+Subscriberid;
        info+="\nSimSerialNumber="+SimSerialNo;
        info+="\nVoiceMailNumber="+voicemailNumber;
        info+="\nPhoneno="+phoneno;
        info+="\nslotemi="+slotemi;
        info+="\nSimOperatorName="+simoperatorname;
        info+="\nStatus="+status;
        info+="\ndatainfo="+datainfo;
        detail.setText(info);
        detail.setGravity(Gravity.LEFT);
        tm.listen(new TeleListener(),PhoneStateListener.LISTEN_CALL_STATE);


    }
    class TeleListener extends PhoneStateListener
    {
        public void OnCallStateChanged(int state,String incomingNumber)
        {
            super.onCallStateChanged(state,incomingNumber);
            switch (state)
            {
                case TelephonyManager.CALL_STATE_IDLE:
                    Toast.makeText(getApplicationContext(),"Call State Idle",Toast.LENGTH_LONG).show();
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    Toast.makeText(getApplicationContext(),"Call State Ofhook",Toast.LENGTH_LONG).show();
                    break;
                case TelephonyManager.CALL_STATE_RINGING:
                    Toast.makeText(getApplicationContext(),"Ring coming from number" + incomingNumber,Toast.LENGTH_LONG).show();
                    break;


            }
        }
    }
}
